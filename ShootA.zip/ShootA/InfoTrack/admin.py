from django.contrib import admin
# Register your models here.
from .models import User, Comment,Post

admin.site.register(User)
admin.site.register(Comment)
admin.site.register(Post)

class CommentInline(admin.TabularInline):
    model = Comment

class PostAdmin(admin.ModelAdmin):
    inlines = [CommentInline]

class PostInline(admin.TabularInline):
    model = Post

class Userdmin(admin.ModelAdmin):
    inlines = [PostInline]